#ifndef ALGORITH_HPP
#define ALGORITH_HPP

#include"gaussian.hpp"
#include"hamiltonian.hpp"

class algorithm
{
public:

  //---------------------------------------------------------------
  //                          Fields 
  //---------------------------------------------------------------
  
  //--- structures ---
  gaussian g;
  particle X;
  hamiltonian* H;
  
  //--- useful constants ---
  double dt, beta, a, boxlg, xi, sig, eps, dcut;
  int nb_replicas, Ndim, np, nb_real;
  int n_iter, n_iter_thm, freq, freq_xmakemol, freq_histo;
  double dx, dy, dist;

  //--- for free energy computation ---
  double SumMeanForces,  Time, SumWork, SumWorkUpdate, theta;
  int    N_lambda, selection, n_slices;
  Vector Bias, MeanForce, Lambda;
  Vector DU_fwd, DU_bck, DU_middle;
  
  //--- for path sampling
  Matrix old_qx, old_qy, old_px, old_py, old_inter_px, old_inter_py;
  double old_work, path_alpha;
  int rejection;

  //--- Creation: initialize some fields ---
  algorithm(const input I)
  { 
    nb_replicas   = I.nb_replicas;
    beta          = I.beta;
    a             = I.a;
    Ndim          = I.Ndim;
    np            = I.Ndim*I.Ndim+1;
    dt            = I.t_step;
    n_iter        = I.nb_iter;
    n_iter_thm    = I.nb_iter_thm;
    boxlg         = I.Ndim*I.a;
    xi            = I.xi;
    freq          = I.freq;
    freq_xmakemol = I.freq_xmakemol;
    sig           = I.sig;
    eps           = I.eps;
    dcut          = I.rcut;
    N_lambda      = I.N_lambda;
    Time          = I.Time;
    freq_histo    = I.freq_histo;
    selection     = I.selection;
    nb_real       = I.nb_realizations;
    path_alpha    = I.alpha;
    theta         = I.theta;
  }

  //---------------------------------------------------------------
  //                        Functions 
  //---------------------------------------------------------------
  
  //---- Initialization ---
  void Initialize(); 
  void ReInitialize(); 
  void Semi_ReInitialize(); 
  void Periodic  ();
  
  //--- Auxiliary functions ---
  double schedule (double);
  void   Select   ();

  //---- Integrators (sampling) ---
  void Langevin  ();

  //---- Path sampling -------
  void Periodic_path    (int);
  void Hamiltonian_path ();
  void Langevin_path    ();
  void Initial_path     ();

  //--- Main function ---
  void load ();

};
#endif
