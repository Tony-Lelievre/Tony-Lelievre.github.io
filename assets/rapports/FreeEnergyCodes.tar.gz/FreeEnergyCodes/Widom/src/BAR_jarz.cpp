#include "algorithm.hpp"

const double tol_df = 1e-6;
const double alpha  = 0.001;

//-----------------------------
//      Initialization
//----------------------------

void algorithm::Initialize()
{
  //--- Initialize the fields ---
  X.qx.set_size(nb_replicas,np);
  X.qx.zeros();
  X.qy.set_size(nb_replicas,np);
  X.qy.zeros();
  X.px.set_size(nb_replicas,np);
  X.px.zeros();
  X.py.set_size(nb_replicas,np);
  X.py.zeros();
  X.RFx.set_size(nb_replicas,np);
  X.RFx.zeros();
  X.RFy.set_size(nb_replicas,np);
  X.RFy.zeros();
  X.energy.set_size(nb_replicas);
  X.energy.zeros();
  X.potential_energy.set_size(nb_replicas);
  X.potential_energy.zeros();
  X.insertion_energy.set_size(nb_replicas);
  X.insertion_energy.zeros();
  X.Lambda.set_size(nb_replicas);
  X.Lambda.zeros();
  
  //------ jarzynski ------
  N_lambda = (int)floor(Time/dt);
  Lambda.set_size(N_lambda+1);
  Lambda.zeros();  
  Bias.set_size(N_lambda);
  Bias.zeros();
  X.Work_fwd.set_size(nb_replicas);
  X.Work_fwd.zeros();
  X.Work_bck.set_size(nb_replicas);
  X.Work_bck.zeros();
  X.WorkUpdate.set_size(nb_replicas);
  X.WorkUpdate.zeros();
  X.Birth.set_size(nb_replicas);
  X.Birth.zeros();
  X.Death.set_size(nb_replicas);
  X.Death.zeros();
  X.nb_death = 0.;
  X.nb_birth = 0.;
  
  //--------- Loop over the replicas ---------
  for (int k = 0; k < nb_replicas; k++)
    {
      //---- Random value of lambda -----
      X.Lambda(k) = g.random_number();
      //---- Initial positions: on a lattice ---
      for (int i = 0; i < Ndim; ++i)  
	{
	  for (int j = 0; j < Ndim; ++j)  
	    {
	      X.qx(k,1+i*Ndim+j) = (0.5 + i)*a;
	      X.qy(k,1+i*Ndim+j) = (0.5 + j)*a;
	    }
	}
      //--- Place additional particle in the corner ---
      X.qx(k,0) = 0.;
      X.qy(k,0) = 0.;
      //--- Momenta and random forces ---
      for (int i = 0; i < np; ++i)
	{
      	  X.px(k,i)  = sqrt(1./beta)*g.rand_number(0,1);
      	  X.py(k,i)  = sqrt(1./beta)*g.rand_number(0,1);
      	  X.RFx(k,i) = g.rand_number(0,1);
      	  X.RFy(k,i) = g.rand_number(0,1);
      	}
      //--- birth and death times ---
      if (selection == 1)
	{
	  X.Birth(k) = -log( g.random_number() );
	  X.Death(k) = -log( g.random_number() );
	}	 
    }
  
  //------------------- Screen output --------------------------
  cout << endl;
  cout << "------------------------------------------" << endl;
  cout << "           WIDOM INSERTION : JARZ         " << endl;
  cout << "------------------------------------------" << endl;
  cout << endl;
  cout << "        Initialization performed          " << endl;
  cout << "                                          " << endl;
  cout << "-----  Parameters of the computation -----" << endl;
  cout << endl;
  cout << " Number of realizations         : " << nb_real << endl;
  cout << " Dynamics                       : LANGEVIN " << endl;
  cout << " Time step                 (dt) : " << dt            << endl;
  cout << " Number of replicas             : " << nb_replicas   << endl;
  cout << " Work distribution output freq. : " << freq_histo    << endl; 
  cout << " Outputs   every...steps        : " << freq          << endl; 
  cout << " Friction coefficient      (xi) : " << xi            << endl; 
  cout << " Inverse temperature     (beta) : " << beta          << endl; 
  cout << " Total number of particles (np) : " << np            << endl; 
  cout << " Elementary cell size       (a) : " << a             << endl;
  cout << " Particle density               : " << 1./(a*a)      << endl;
  cout << " LJ equilibrium distance  (sig) : " << sig           << endl; 
  cout << " LJ energy epsilon        (eps) : " << eps           << endl;
  cout << " Switching time                 : " << Time          << endl;
  cout << " Number of intermediate stages  : " << N_lambda      << endl;
  if (selection == 1)
    cout << " SELECTION ON   " << endl;
  cout << endl;
  cout << "----------------------------------------- " << endl;

  cout << endl;
      
}

//---------- ReInitialization ----------
void algorithm::ReInitialize()
{
  //--- Initialize the fields ---
  X.qx.zeros();
  X.qy.zeros();
  X.px.zeros();
  X.py.zeros();
  X.RFx.zeros();
  X.RFy.zeros();
  X.energy.zeros();
  X.potential_energy.zeros();
  X.insertion_energy.zeros();
  X.Lambda.zeros();
  
  //------ jarzynski ------
  Lambda.zeros();  
  Bias.zeros();
  X.Work_fwd.zeros();
  X.Work_bck.zeros();
  X.WorkUpdate.zeros();
  X.Birth.zeros();
  X.Death.zeros();
  X.nb_death = 0.;
  X.nb_birth = 0.;
  
  //--------- Loop over the replicas ---------
  for (int k = 0; k < nb_replicas; k++)
    {
      //---- Random value of lambda -----
      X.Lambda(k) = g.random_number();
      //---- Initial positions: on a lattice ---
      for (int i = 0; i < Ndim; ++i)  
	{
	  for (int j = 0; j < Ndim; ++j)  
	    {
	      X.qx(k,1+i*Ndim+j) = (0.5 + i)*a;
	      X.qy(k,1+i*Ndim+j) = (0.5 + j)*a;
	    }
	}
      //--- Place additional particle in the corner ---
      X.qx(k,0) = 0.;
      X.qy(k,0) = 0.;
      //--- Momenta and random forces ---
      for (int i = 0; i < np; ++i)
	{
      	  X.px(k,i)  = sqrt(1./beta)*g.rand_number(0,1);
      	  X.py(k,i)  = sqrt(1./beta)*g.rand_number(0,1);
      	  X.RFx(k,i) = g.rand_number(0,1);
      	  X.RFy(k,i) = g.rand_number(0,1);
      	}
      //--- birth and death times ---
      if (selection == 1)
	{
	  X.Birth(k) = -log( g.random_number() );
	  X.Death(k) = -log( g.random_number() );
	}	 
    }
  
  cout << endl;
  cout << "------------------------------------------" << endl;
  cout << "         REINITIALIZATION PERFORMED       " << endl;
  cout << "------------------------------------------" << endl;
  cout << endl;
      
}

//---------- ReInitialization ----------
void algorithm::Semi_ReInitialize()
{
  //--- Initialize the fields ---
  X.Lambda.zeros();
  
  //------ jarzynski ------
  Lambda.zeros();  
  Bias.zeros();
  X.WorkUpdate.zeros();
  X.Birth.zeros();
  X.Death.zeros();
  X.nb_death = 0.;
  X.nb_birth = 0.;

}

//---------------------------------------------------------
//   Integration of the dynamics and auxiliary functions
//---------------------------------------------------------

//
double algorithm::schedule(double x)
{
  double val = pow(x,2);
  return val;
}

//-------- Apply periodic boundary conditions ---------
void algorithm::Periodic()
{
  Matrix temp;

  //-- x direction ---
  temp = X.qx;
  for (int k = 0; k < nb_replicas; k++)
    for (int i = 0; i < np; i++)
      temp(k,i) -= boxlg*floor( temp(k,i)*1./boxlg );
  X.qx = temp;

  //--- y direction
  temp = X.qy;
  for (int k = 0; k < nb_replicas; k++)
    for (int i = 0; i < np; i++) 
      temp(k,i) = temp(k,i) - boxlg*floor( temp(k,i)*1./boxlg );
  X.qy = temp;

}

//------------ Langevin dynamics -----------------------
void algorithm::Langevin()
{
  double sigma = sqrt(2*xi/beta);
  
  //--- BBK like algorithm ---
  for (int k = 0; k < nb_replicas; k++)
    {
      //--- Random terms
      for (int i = 0; i < np; ++i)
	{
	  X.RFx(k,i) = g.rand_number(0,1);
	  X.RFy(k,i) = g.rand_number(0,1);
	} 
      //--- random part of the force ---
      for (int i = 0; i < np; ++i)
	{
	  H->fx(k,i) += - xi*X.px(k,i) + sqrt(1/dt)*sigma*X.RFx(k,i);
	  H->fy(k,i) += - xi*X.py(k,i) + sqrt(1/dt)*sigma*X.RFy(k,i);
	} 
      for (int i = 0; i < np; ++i)
	{
	  //--- momenta update ---
	  X.px(k,i) += 0.5*dt*H->fx(k,i);
	  X.py(k,i) += 0.5*dt*H->fy(k,i);
	  //--- position update
	  X.qx(k,i) += dt*X.px(k,i);
	  X.qy(k,i) += dt*X.py(k,i);
	} 
    }
  //--- Apply periodic BC on positions --- 
  Periodic();
  //--- Update the forces ---
  H->compute_force(X);
  //--- Final update of the momenta ---
  for (int k = 0; k < nb_replicas; k++)
    {
      for(int i = 0 ; i < np; i++)
	{
	  X.px(k,i) = 1/( 1 + xi*dt*0.5 )
	    *( X.px(k,i) + H->fx(k,i)*dt*0.5 + 0.5*sqrt(dt)*sigma*X.RFx(k,i) );
	  X.py(k,i) = 1/( 1 + xi*dt*0.5 )
	    *( X.py(k,i) + H->fy(k,i)*dt*0.5 + 0.5*sqrt(dt)*sigma*X.RFy(k,i) );
	} 
    }
  //--- Add kinetic energy to the total energy ---
  H->add_k_energy(X);
  
  //--- End of Langevin ---
}

//--- Selection procedure ----
void algorithm::Select()
{
  double MeanWorkUpdate = SumWorkUpdate/nb_replicas;
  double diff = 0;
  int    ind;
  //----- Update the birth/death times -----
  for (int k = 0; k < nb_replicas; k++)
    {
      diff = X.WorkUpdate(k) - MeanWorkUpdate;
      //-- if the work update is larger than the average,
      //   decrease the death time, otherwise, decrease 
      //   the birth time (favor this configuration)
      if ( diff > 0)
	X.Death(k) -= beta*diff; 
      else
	X.Birth(k) += beta*diff; 
    }
  //----- Resampling step when some time < 0 ----
  for(int k = 0 ; k < nb_replicas; k++)
    {
      //--- Check death ---
      if (X.Death(k) < 0)  
	{
	  //--- Update total number of deaths ---
	  X.nb_death += 1;
	  //--- New exponential clock ---
	  X.Death(k) = -log( g.random_number() );
	  //--- Choose the new position, and replace ---
	  ind = (int) floor(g.random_number()*nb_replicas);
	  for (int i = 0; i < np; i++)
	    {
	      X.qx(k,i) = X.qx(ind,i);
	      X.qy(k,i) = X.qy(ind,i);
	      X.px(k,i) = X.px(ind,i);
	      X.py(k,i) = X.py(ind,i);
	    }
	  X.energy(k)           = X.energy(ind);
	  X.potential_energy(k) = X.potential_energy(ind);
	  X.insertion_energy(k) = X.insertion_energy(ind);
	}
      //--- Check birth ---
      if (X.Birth(k) < 0)  
	{
	  //--- Update total number of deaths ---
	  X.nb_birth += 1;
	  //--- New exponential clock ---
	  X.Birth(k) = -log( g.random_number() );
	  //--- Choose the new position, and replace ---
	  ind = (int) floor(g.random_number()*nb_replicas);
	  for (int i = 0; i < np; i++)
	    {
	      X.qx(ind,i) = X.qx(k,i);
	      X.qy(ind,i) = X.qy(k,i);
	      X.px(ind,i) = X.px(k,i);
	      X.py(ind,i) = X.py(k,i);
	    }
	  X.energy(ind)           = X.energy(k);
	  X.potential_energy(ind) = X.potential_energy(k);
	  X.insertion_energy(ind) = X.insertion_energy(k);
	}
    }
  //------------ End of selection procedure -----------
}

//----------------------------------------------------------
//
//     Sampling procedure = compute the trajectory
//
//----------------------------------------------------------

void algorithm::load()
{
  
  //--------------- Useful fields ---------------------
  ofstream ENERGY   ("../output/energy");    // instantaneous work distributions
  ofstream WORK     ("../output/work");      // current estimate of mean force
  ofstream BIAS     ("../output/PMF");       // free energy profile
  ofstream ESTIMATE ("../output/DeltaF");    // Estimate of the free energy difference
  double time;
  
  //------------- Initialization ----------------------
  Initialize();
  int acquisition       = -1;
  int acquisition_histo = -1;
  double df, df_fwd, df_bck;
  
  //------------- Loop over the realizations ---------
  for (int Real = 0; Real < nb_real; Real++)
    {

      //---------------------------------------------
      //---------- FORWARD SWITCHING ----------------
      //---------------------------------------------
      ReInitialize();
      H->compute_force(X);
      acquisition       = -1;
      acquisition_histo = -1;
      //--- Choose switching schedule ---
      for (int i = 0; i < 1+N_lambda; i++)
	Lambda(i) = schedule(i*1./N_lambda);
      //--- Free energy at initial point ---
      BIAS << 0 << "  " << 0 << endl;
      cout << "------- FORWARD Computation started -------" << endl;
      cout << endl;
      cout << "     Realization : " << Real+1 << endl;
      cout << endl;
      //--------------- Preliminary thermalization --------
      cout << " --- creation of initial conditions " << endl;
      for (int k = 0; k < nb_replicas; k++)
	X.Lambda(k) = 0;
      for(int Niter = 0; Niter < n_iter_thm; Niter++)
	Langevin();
      //-------------- Loop over time ---------------------
      cout << " --- production " << endl;
      for(int Niter = 1; Niter < N_lambda+1; Niter++)
	{
	  //--- Update the works and the \lambda variables ---
	  SumWork       = 0.;
	  SumWorkUpdate = 0.;
	  for (int k = 0; k < nb_replicas; k++)
	    {
	      X.WorkUpdate(k) = X.insertion_energy(k)*(Lambda(Niter)-Lambda(Niter-1));
	      X.Work_fwd(k) += X.WorkUpdate(k);
	      SumWork += exp(-beta*X.Work_fwd(k));
	      X.Lambda(k) = Lambda(Niter);
	    }
	  BIAS << Lambda(Niter) << "  " << -1./beta*log(SumWork/nb_replicas) << endl;
	  //---- Switching dynamics ----
	  Langevin();
	  //--- Outputs ---
	  acquisition += 1;
	  time = (Niter-1)*dt;
	  if (acquisition == freq)
	    {
	      acquisition = 0;
	      ENERGY << time << " " << X.energy(0) << " " 
		     << X.potential_energy(0) << " " 
		     << X.insertion_energy(0) << endl;
	    }
	  //--- Work distributions ---
	  acquisition_histo += 1;
	  if (acquisition_histo == freq_histo) 
	    { 
	      acquisition_histo = 0.;
	      cout << "     Output at time " << (Niter-1)*dt << endl;
	      for (int k = 0; k < nb_replicas; k++)
		WORK << X.Work_fwd(k) << "  ";
	      WORK << endl;
	    }
	}
      //--- Final output of Work distributions ---
      acquisition_histo = 0.;
      cout << "     Output at time " << Time << endl;
      for (int k = 0; k < nb_replicas; k++)
	WORK << X.Work_fwd(k) << "  ";
      WORK << endl;
      //----- ACQUIRE THE ESTIMATED FREE ENERGY DIFFERENCE  ------
      SumWork = 0;
      for (int k = 0; k < nb_replicas; k++)
	SumWork += exp(-beta*X.Work_fwd(k));
      df_fwd = -1./beta*log(SumWork/nb_replicas);
      ESTIMATE << df_fwd << "  ";
      
      //----------------------------------------------
      //---------- BACKWARD SWITCHING ----------------
      //----------------------------------------------
      Semi_ReInitialize();
      H->compute_force(X);
      acquisition       = -1;
      acquisition_histo = -1;
      //--- Choose switching schedule ---
      for (int i = 0; i < 1+N_lambda; i++)
	Lambda(i) = schedule(1-i*1./N_lambda);
      //--- Free energy at initial point ---
      BIAS << 0 << "  " << 0 << endl;
      cout << endl;
      cout << "------- BACKWARD Computation started -------" << endl;
      cout << endl;
      cout << "     Realization : " << Real+1 << endl;
      cout << endl;
      //--------------- Preliminary thermalization --------
      cout << " --- creation of initial conditions " << endl;
      for (int k = 0; k < nb_replicas; k++)
	X.Lambda(k) = 1;
      for(int Niter = 0; Niter < n_iter_thm; Niter++)
	Langevin();
      //-------------- Loop over time ---------------------
      cout << " --- production " << endl;
      for(int Niter = 1; Niter < N_lambda+1; Niter++)
	{
	  //--- Update the works and the \lambda variables ---
	  SumWork       = 0.;
	  SumWorkUpdate = 0.;
	  for (int k = 0; k < nb_replicas; k++)
	    {
	      X.WorkUpdate(k) = X.insertion_energy(k)*(Lambda(Niter)-Lambda(Niter-1));
	      X.Work_bck(k) += X.WorkUpdate(k);
	      SumWork += exp(beta*X.Work_bck(k));
	      X.Lambda(k) = Lambda(Niter);
	    }
	  BIAS << Lambda(Niter) << "  " << 1./beta*log(SumWork/nb_replicas) << endl;
	  //--- Selection procedure if requested ---
	  if (selection == 1)
	    Select();
	  //---- Switching dynamics ----
	  Langevin();
	  //--- Outputs ---
	  acquisition += 1;
	  time = (Niter-1)*dt;
	  if (acquisition == freq)
	    {
	      acquisition = 0;
	      ENERGY << time << " " << X.energy(0) << " " 
		     << X.potential_energy(0) << " " 
		     << X.insertion_energy(0) << endl;
	    }
	  //--- Work distributions ---
	  acquisition_histo += 1;
	  if (acquisition_histo == freq_histo) 
	    { 
	      acquisition_histo = 0.;
	      cout << "     Output at time " << (Niter-1)*dt << endl;
	      for (int k = 0; k < nb_replicas; k++)
		WORK << X.Work_bck(k) << "  ";
	      WORK << endl;
	    }
      	}
      //--- Final output of Work distributions ---
      acquisition_histo = 0.;
      cout << "     Output at time " << Time << endl;
      for (int k = 0; k < nb_replicas; k++)
	WORK << X.Work_bck(k) << "  ";
      WORK << endl;
      //----- ACQUIRE THE ESTIMATED FREE ENERGY DIFFERENCE  ------
      SumWork = 0;
      for (int k = 0; k < nb_replicas; k++)
	SumWork += exp(-beta*X.Work_bck(k));
      df_bck = 1./beta*log(SumWork/nb_replicas);
      ESTIMATE << df_bck << "  ";

      //---------------------------------------
      //------------- BAR ESTIMATION ----------
      //---------------------------------------
      // initial guess for the free energy difference = simple average
      df = 0.5*(df_bck+df_fwd);
      double UpdateDF = 1;
      // estimate using a very simple fixed point strategy
      // i.e. F(x) = 0 equivalent to x + \alpha * F(x) = x
      // scheme x^{n+1} = x^n + \alpha * F(x^n)
      while (fabs(UpdateDF) > tol_df)
	{
	  UpdateDF = 0;
	  for (int k = 0; k < nb_replicas; k++)
	    {
	      UpdateDF += 1/( 1 + exp(beta*(df+X.Work_bck(k)) ));
	      UpdateDF -= 1/( 1 + exp(beta*(X.Work_fwd(k))-df ));
	    }
	  df += alpha*UpdateDF;
	}
      ESTIMATE << df << endl;
      
      //-------- end of loops over realizations --------
    }
  
  //------------- End of computation ---------------
  cout << endl;
  cout << "------- End of computation ------" << endl;
  cout << endl;
  cout << endl;
}









