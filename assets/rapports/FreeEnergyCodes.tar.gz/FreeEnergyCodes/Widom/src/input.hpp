//-----------------------------------------------------
//
//     Reading parameters from "input_file_..."
//
//-----------------------------------------------------


#ifndef INPUT_HPP
#define INPUT_HPP

#include <iostream>
#include <fstream>
#include <cmath>
#include <iomanip>
#include <string>
#include <cstring>
#include <cstdlib>

using namespace std;

//--------------- definition of the structure --------
class input
{
public:
 
  //------------------------ FIELDS --------------------------
  
  //--- Simulation parameters ---
  int    nb_realizations; // number of independent realizations
  double t_step;          // time step for the time integrator algorithm
  int    nb_iter;         // number of iterations
  int    nb_iter_thm;     // preliminary thermalization (when needed)
  int    freq_xmakemol;   // XMakeMol output frequency
  int    freq;            // outputs written every 'freq' steps (energy, reaction coordinate, ...)
  int    freq_histo;      // output frequency for work distributions (jarzynski)
  double xi;              // friction coefficient for Langevin dynamics
  int    nb_replicas;     // number of replicas
  double beta;            // inverse temperature

  //--- Thermodynamic conditions ---
  int    Ndim;           // Ndim^2 particles + "1 virtual" one  
  double a;              // domain [0,Ndim*a]^2, volume = (Ndim*a)^2

  //--- Potential parameters ---
  double sig, eps, rcut; 
 
  //---- Free energy difference computation ---
  int    N_lambda;       // Number of intermediate stages (TI)
  double Time;           // Switching time (Jarzynski)
  int    selection;      // Select or not for Jarzynski switching
  double theta;          // for Umbrella sampling

  //--- path sampling ---
  double alpha;          // weighted path ensembles parameter

  //---------------------- READING FUNCTIONS --------------------------
  
  template <class T>
  //--- elementary reading function -------
  void read_item(istream& ,char *, T *); 
  //--- copying datas from input_file to the parameters class ---
  void load(void);
  //--- reading the input file for "sampling" ------
  void read_sampling(double&,int&,int&,int&,double&,double&,int&,double&,double&,double&,double&);
  //--- reading the input file for "TI" ------
  void read_TI(double&,int&,int&,int&,double&,double&,int&,double&,double&,double&,double&,int&);
  //--- reading the input file for "FEP" ------
  void read_FEP(double&,int&,int&,double&,int&,double&,double&,int&,double&,double&,double&,double&);
  //--- reading the input file for "jarz" ------
  void read_jarz(int&,double&,int&,int&,int&,int&,double&,double&,int&,double&,double&,double&,double&,double&,int&);
  //--- reading the input file for "path" ------
  void read_path(int&,double&,int&,int&,double&,double&,int&,double&,double&,double&,double&,double&,double&);
 
};

#endif

