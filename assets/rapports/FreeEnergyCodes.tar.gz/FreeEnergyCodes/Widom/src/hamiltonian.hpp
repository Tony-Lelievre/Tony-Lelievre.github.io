#include"particle.hpp"

class hamiltonian
{
public:
  
  //---------------------------------------------------------------
  //                          Fields 
  //---------------------------------------------------------------

  //--- constants for force computations ---
  int    np;         // total number of particle = 1+I.Ndim^2
  int    nb_sys;     // number of replicas simulated in parallel
  double boxlg;      // periodicity length
  
  //---- Parameters of the potential -------
  double dcut;       // cut-off radius for potential
  double sig, eps;   // parameters for Lennard-Jones potential
  double A, B, C, D; // parameters for regularized LJ potential

  //--- Force matrices ---
  Matrix fx, fy;
  double act, dx, dy, dist;  // useful variables for force computations

  //--- Creation: initialize some fields ---
  hamiltonian(const input I)
  { 
    // constants
    np     = I.Ndim*I.Ndim+1;;         
    nb_sys = I.nb_replicas;        
    dcut   = I.rcut;
    boxlg  = I.Ndim*I.a;
    eps    = I.eps;
    sig    = I.sig;
    // truncature and regularization of LJ potential
    D = 2*eps*( 0.5*pow(sig/dcut,12) - pow(sig/dcut,6)); 
    C = 12*eps*( pow(sig/dcut,12)-pow(sig/dcut,6) )/dcut;  
    B = ( -12.*eps*( pow(1./0.8,13) - pow(1./0.8,7) ) + C )/1.6/sig;
    A = 2*eps*( 0.5*pow(1/0.8,12) - pow(1/0.8,6)) - 0.64*B;
    // matrices
    fx.set_size(nb_sys,np);
    fx.zeros();
    fy.set_size(nb_sys,np);
    fy.zeros();
  }
  
  //---------------------------------------------------------------
  //                        Functions 
  //---------------------------------------------------------------

  //--- Kinetic energy ---
  void add_k_energy(particle&);

  //--- Elementary forces ---
  void   lengthBC  (double,double,double,double);
  double potential (double);
  double force     (double);
  
  //--- global force computations ---
  void   compute_force (particle&);

  //--- for path sampling: force at given slice ---
  void   compute_force_path (particle&, int);

};




