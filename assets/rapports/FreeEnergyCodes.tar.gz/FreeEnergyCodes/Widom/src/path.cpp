#include "algorithm.hpp"

//-----------------------------
//      Initialization
//----------------------------

void algorithm::Initialize()
{
  //------ jarzynski ------
  n_slices = (int)floor(Time/dt);
  X.Lambda.set_size(n_slices);
  X.Lambda.zeros();
  X.Work.set_size(n_slices);
  X.Work.zeros();
  X.WorkUpdate.set_size(n_slices);
  X.WorkUpdate.zeros();
  
  //--- Initialize the fields ---
  X.qx.set_size(n_slices,np);
  X.qx.zeros();
  X.qy.set_size(n_slices,np);
  X.qy.zeros();
  X.px.set_size(n_slices,np);
  X.px.zeros();
  X.py.set_size(n_slices,np);
  X.py.zeros();
  X.RFx.set_size(n_slices,np);
  X.RFx.zeros();
  X.RFy.set_size(n_slices,np);
  X.RFy.zeros();
  X.energy.set_size(n_slices);
  X.energy.zeros();
  X.potential_energy.set_size(n_slices);
  X.potential_energy.zeros();
  X.insertion_energy.set_size(n_slices);
  X.insertion_energy.zeros();
  
  //----- path sampling ----
  rejection = 0;
  old_qx.set_size(n_slices,np);
  old_qx.zeros();
  old_qy.set_size(n_slices,np);
  old_qy.zeros();
  old_px.set_size(n_slices,np);
  old_px.zeros();
  old_py.set_size(n_slices,np);
  old_py.zeros();
  old_inter_px.set_size(n_slices,np);
  old_inter_px.zeros();
  old_inter_py.set_size(n_slices,np);
  old_inter_py.zeros();
  X.inter_px.set_size(n_slices,np);
  X.inter_px.zeros();
  X.inter_py.set_size(n_slices,np);
  X.inter_py.zeros();
  X.work = 0;
  
  //--------- Loop over the path configurations ---------
  for (int k = 0; k < n_slices; k++)
    {
      //---- Initial positions: on a lattice ---
      for (int i = 0; i < Ndim; ++i)  
	{
	  for (int j = 0; j < Ndim; ++j)  
	    {
	      X.qx(k,1+i*Ndim+j) = (0.5 + i)*a;
	      X.qy(k,1+i*Ndim+j) = (0.5 + j)*a;
	    }
	}
      //--- Place additional particle in the corner ---
      X.qx(k,0) = 0.;
      X.qy(k,0) = 0.;
      //--- Momenta and random forces ---
      for (int i = 0; i < np; ++i)
	{
      	  X.px(k,i)  = sqrt(1./beta)*g.rand_number(0,1);
      	  X.py(k,i)  = sqrt(1./beta)*g.rand_number(0,1);
      	  X.RFx(k,i) = g.rand_number(0,1);
      	  X.RFy(k,i) = g.rand_number(0,1);
      	}
    }
  
  //------------------- Screen output --------------------------
  cout << endl;
  cout << "------------------------------------------" << endl;
  cout << "           WIDOM INSERTION : PATH         " << endl;
  cout << "------------------------------------------" << endl;
  cout << endl;
  cout << "        Initialization performed          " << endl;
  cout << "                                          " << endl;
  cout << "-----  Parameters of the computation -----" << endl;
  cout << endl;
  cout << " Dynamics                       : LANGEVIN " << endl;
  cout << " Number of MC iterations        : " << n_iter     << endl;
  cout << " Therm. steps initial condition : " << n_iter_thm << endl;
  cout << " Time step                 (dt) : " << dt         << endl;
  cout << " Outputs   every...steps        : " << freq       << endl; 
  cout << " Friction coefficient      (xi) : " << xi         << endl; 
  cout << " Inverse temperature     (beta) : " << beta       << endl; 
  cout << " Total number of particles (np) : " << np         << endl; 
  cout << " Elementary cell size       (a) : " << a          << endl;
  cout << " Particle density               : " << 1./(a*a)   << endl;
  cout << " LJ equilibrium distance  (sig) : " << sig        << endl; 
  cout << " LJ energy epsilon        (eps) : " << eps        << endl;
  cout << " Switching time                 : " << Time       << endl;
  cout << " Configurations along the path  : " << n_slices   << endl;
  cout << " Path weighting                 : " << path_alpha << endl;
  cout << endl;
  cout << "----------------------------------------- " << endl;
  cout << endl;
      
}


//---------------------------------------------------------
//   Integration of the dynamics and auxiliary functions
//---------------------------------------------------------

//
double algorithm::schedule(double x)
{
  double val = pow(x,4);
  return val;
}

//-------- Apply periodic boundary conditions for l-th configuration ---------
void algorithm::Periodic_path(int l)
{
  //-- x direction ---
  for (int i = 0; i < np; i++)
    X.qx(l,i) -= boxlg*floor( X.qx(l,i)*1./boxlg );
  //-- y direction ---
  for (int i = 0; i < np; i++)
    X.qy(l,i) -= boxlg*floor( X.qy(l,i)*1./boxlg );
}

//-------- Langevin dynamics: thermalization of initial condition -------
void algorithm::Langevin()
{
  double sigma = sqrt(2*xi/beta);
  //--- Random terms
  for (int i = 0; i < np; ++i)
    {
      X.RFx(0,i) = g.rand_number(0,1);
      X.RFy(0,i) = g.rand_number(0,1);
    } 
  //--- random part of the force ---
  for (int i = 0; i < np; ++i)
    {
      H->fx(0,i) += - xi*X.px(0,i) + sqrt(1/dt)*sigma*X.RFx(0,i);
      H->fy(0,i) += - xi*X.py(0,i) + sqrt(1/dt)*sigma*X.RFy(0,i);
    } 
  for (int i = 0; i < np; ++i)
    {
      //--- momenta update ---
      X.px(0,i) += 0.5*dt*H->fx(0,i);
      X.py(0,i) += 0.5*dt*H->fy(0,i);
      //--- position update
      X.qx(0,i) += dt*X.px(0,i);
      X.qy(0,i) += dt*X.py(0,i);
    } 
  //--- Apply periodic BC on positions --- 
  Periodic_path(0);
  //--- Update the forces ---
  H->compute_force_path(X,0);
  //--- Final update of the momenta ---
  for(int i = 0 ; i < np; i++)
    {
      X.px(0,i) = 1/( 1 + xi*dt*0.5 )
	*( X.px(0,i) + H->fx(0,i)*dt*0.5 + 0.5*sqrt(dt)*sigma*X.RFx(0,i) );
      X.py(0,i) = 1/( 1 + xi*dt*0.5 )
	*( X.py(0,i) + H->fy(0,i)*dt*0.5 + 0.5*sqrt(dt)*sigma*X.RFy(0,i) );
    } 
  //--- Add kinetic energy ---
  for (int i = 0; i < np; i++)
    X.energy(0) += 0.5*X.px(0,i)*X.px(0,i) + 0.5*X.py(0,i)*X.py(0,i);
  //--- End of simple Langevin ---
}

//------------ Construction of initial path -----------------------
void algorithm::Initial_path()
{
  H->compute_force_path(X,0);
  X.Work(0) = 0;
  for (int k = 1; k < n_slices; k++)
    {
      H->compute_force_path(X,k-1);
      X.Work(k) = X.Work(k-1) + (X.Lambda(k)-X.Lambda(k-1))*X.insertion_energy(k-1);
      //--- Verlet integrator ---
      for (int i = 0; i < np; ++i)
	{
	  //--- momenta update ---
	  X.px(k,i) = X.px(k-1,i) + 0.5*dt*H->fx(k-1,i);
	  X.py(k,i) = X.py(k-1,i) + 0.5*dt*H->fy(k-1,i);
	  //--- position update
	  X.qx(k,i) = X.qx(k-1,i) + dt*X.px(k,i);
	  X.qy(k,i) = X.qy(k-1,i) + dt*X.py(k,i);
	} 
      //--- Apply periodic BC on positions --- 
      Periodic_path(k);
      //--- Update the forces ---
      H->compute_force_path(X,k);
      //--- Final update of the momenta ---
      for(int i = 0 ; i < np; i++)
	{
	  X.px(k,i) += H->fx(k,i)*dt*0.5; 
	  X.py(k,i) += H->fy(k,i)*dt*0.5;
	  X.inter_px(k,i) = X.px(k,i);
	  X.inter_py(k,i) = X.py(k,i);
	} 
    }
  X.work = X.Work(n_slices-1);
  //--- End of path construction ---
}


//------------ Path modification (Hamiltonian dynamics) -----------------------
//
//   NOT USED FOR THE MOMENT! UNCOMMENT THE CORRESPONDING LINE IN 
//     THE FUNCTION 'load' + CHANGE mod_p, mod_q VARIABLES BELOW
//-----------------------------------------------------------------------------
void algorithm::Hamiltonian_path()
{
  //--- choice of shooting index ---
  int ind = (int)floor( n_slices*g.random_number() );
  H->compute_force_path(X,ind);
  //--- keep old path in memory
  for (int k = 0; k < n_slices; k++)
    {
      for (int i = 0; i < np; ++i)
	{
	  old_px(k,i) = X.px(k,i); 
	  old_py(k,i) = X.py(k,i); 
	  old_qx(k,i) = X.qx(k,i);
	  old_qy(k,i) = X.qy(k,i);
	}
    }
  //--- probability of initial point ---
  H->compute_force_path(X,0);
  double initial_energy = X.energy(0);
  for (int i = 0; i < np; i++)
    initial_energy += 0.5*X.px(0,i)*X.px(0,i) + 0.5*X.py(0,i)*X.py(0,i);
  //--- modify shooting point (in a symmetric way, to simplify) ---
  double mod_p = 0.02;   // these coefficients should be modified 
  double mod_q = 0.02;   // to obtain the best convergence ppties
  for (int i = 0; i < np; ++i)
    {
      X.px(ind,i) += mod_p*g.rand_number(0,1);
      X.py(ind,i) += mod_p*g.rand_number(0,1);
      X.qx(ind,i) += mod_q*g.rand_number(0,1);
      X.qy(ind,i) += mod_q*g.rand_number(0,1);
    }
  //--- Construction of new path: forward integration ---
  for (int k = ind+1; k < n_slices; k++)
    {
      for (int i = 0; i < np; ++i)
	{
	  //--- momenta update ---
	  X.px(k,i) = X.px(k-1,i) + 0.5*dt*H->fx(k-1,i);
	  X.py(k,i) = X.py(k-1,i) + 0.5*dt*H->fy(k-1,i);
	  //--- position update
	  X.qx(k,i) = X.qx(k-1,i) + dt*X.px(k,i);
	  X.qy(k,i) = X.qy(k-1,i) + dt*X.py(k,i);
	} 
      //--- Apply periodic BC on positions --- 
      Periodic_path(k);
      //--- Update the forces ---
      H->compute_force_path(X,k);
      //--- Final update of the momenta ---
      for(int i = 0 ; i < np; i++)
	{
	  X.px(k,i) += H->fx(k,i)*dt*0.5;
	  X.py(k,i) += H->fy(k,i)*dt*0.5;
	} 
    }
  //--- Construction of new path: backward integration ---
  H->compute_force_path(X,ind);
  //-- revert momenta --
  for (int i = 0; i < np; ++i)
    {
      X.px(ind,i) = -X.px(ind,i);
      X.py(ind,i) = -X.py(ind,i);
    }
  //-- integrate "forward" with momenta reverted --
  for (int k = ind; k > 0; k--)
    {
      for (int i = 0; i < np; ++i)
	{
	  //--- momenta update ---
	  X.px(k-1,i) = X.px(k,i) + 0.5*dt*H->fx(k,i);
	  X.py(k-1,i) = X.py(k,i) + 0.5*dt*H->fy(k,i);
	  //--- position update
	  X.qx(k-1,i) = X.qx(k,i) + dt*X.px(k-1,i);
	  X.qy(k-1,i) = X.qy(k,i) + dt*X.py(k-1,i);
	} 
      //--- Apply periodic BC on positions --- 
      Periodic_path(k-1);
      //--- Update the forces ---
      H->compute_force_path(X,k-1);
      //--- Final update of the momenta ---
      for(int i = 0 ; i < np; i++)
	{
	  //--- momenta update ---
	  X.px(k-1,i) += H->fx(k-1,i)*dt*0.5;
	  X.py(k-1,i) += H->fy(k-1,i)*dt*0.5;
	} 
    }
  //-- revert momenta again --
  for (int k = 0; k < ind+1; k++)
    {
      for (int i = 0; i < np; ++i)
	{
	  X.px(k,i) = -X.px(k,i);
	  X.py(k,i) = -X.py(k,i);
	}
    }
  //--- probability of the initial point of modified path ---
  H->compute_force_path(X,0);
  double final_energy = X.energy(0);
  for (int i = 0; i < np; i++)
    final_energy += 0.5*X.px(0,i)*X.px(0,i) + 0.5*X.py(0,i)*X.py(0,i);
  //--- acceptance/rejection step ---
  double ratio = exp(-beta*(final_energy-initial_energy));
  if (ratio < g.random_number()) 
    {
      // rejection in this case
      rejection += 1;
      // go back to original path
      for (int k = 0; k < n_slices; k++)
	{
	  for (int i = 0; i < np; ++i)
	    {
	      X.px(k,i) = old_px(k,i); 
	      X.py(k,i) = old_py(k,i); 
	      X.qx(k,i) = old_qx(k,i);
	      X.qy(k,i) = old_qy(k,i);
	    }
	}
    }
  //--- Computation of the work in any case ---
  X.Work(0) = 0.;
  for (int k = 1; k < n_slices; k++)
    {
      H->compute_force_path(X,k-1);
      X.Work(k) = X.Work(k-1) + (X.Lambda(k)-X.Lambda(k-1))*X.insertion_energy(k-1);
    }
  //------------ End of path modification  -------------
}

//------------ Path modification (Langevin dynamics) -----------------------
void algorithm::Langevin_path()
{
  //--- Ornstein-Uhlenbeck modification magnitude ---
  double alpha = exp(-xi*dt);
  //--- choice of shooting index ---
  int ind = (int)floor( n_slices*g.random_number() );
  H->compute_force_path(X,ind);
  //--- keep old path in memory
  old_work = X.work;
  for (int k = 0; k < n_slices; k++)
    {
      for (int i = 0; i < np; ++i)
	{
	  old_px(k,i) = X.px(k,i); 
	  old_py(k,i) = X.py(k,i); 
	  old_qx(k,i) = X.qx(k,i);
	  old_qy(k,i) = X.qy(k,i);
	  old_inter_px(k,i) = X.inter_px(k,i); 
	  old_inter_py(k,i) = X.inter_py(k,i); 
	}
    }
  //--- probability of initial point ---
  H->compute_force_path(X,0);
  double initial_energy = X.energy(0);
  for (int i = 0; i < np; i++)
    initial_energy += 0.5*X.px(0,i)*X.px(0,i) + 0.5*X.py(0,i)*X.py(0,i);
  //--- Construction of new path: forward integration ---
  for (int k = ind+1; k < n_slices; k++)
    {
      //--- Verlet step ---
      for (int i = 0; i < np; ++i)
	{
	  //--- momenta update ---
	  X.px(k,i) = X.px(k-1,i) + 0.5*dt*H->fx(k-1,i);
	  X.py(k,i) = X.py(k-1,i) + 0.5*dt*H->fy(k-1,i);
	  //--- position update
	  X.qx(k,i) = X.qx(k-1,i) + dt*X.px(k,i);
	  X.qy(k,i) = X.qy(k-1,i) + dt*X.py(k,i);
	} 
      //--- Apply periodic BC on positions --- 
      Periodic_path(k);
      //--- Update the forces ---
      H->compute_force_path(X,k);
      //--- Final update of the momenta ---
      for(int i = 0 ; i < np; i++)
	{
	  X.px(k,i) += H->fx(k,i)*dt*0.5;
	  X.py(k,i) += H->fy(k,i)*dt*0.5;
	}
      //--- Ornstein-Uhlenbeck step ---
      for (int i = 0; i < np; ++i)
	{
	  X.inter_px(k,i) = X.px(k,i);
	  X.inter_py(k,i) = X.py(k,i);
	  X.px(k,i) = alpha*X.px(k,i) + sqrt((1-alpha*alpha)/beta) * g.rand_number(0,1);
	  X.py(k,i) = alpha*X.py(k,i) + sqrt((1-alpha*alpha)/beta) * g.rand_number(0,1);
	}
    }
  //--- Construction of new path: backward integration ---
  H->compute_force_path(X,ind);
  //-- integrate "forward" with momenta reverted and *adjoint* integrator --
  for (int k = ind; k > 0; k--)
    {
      //--- Ornstein-Uhlenbeck step ---
      for (int i = 0; i < np; ++i)
	{
	  X.inter_px(k,i) = alpha*X.px(k,i) + sqrt((1-alpha*alpha)/beta) * g.rand_number(0,1);
	  X.inter_py(k,i) = alpha*X.py(k,i) + sqrt((1-alpha*alpha)/beta) * g.rand_number(0,1);
	}
      for (int i = 0; i < np; ++i)
	{
	  //--- momenta update ---
	  X.px(k-1,i) = -X.inter_px(k,i) + 0.5*dt*H->fx(k,i);
	  X.py(k-1,i) = -X.inter_py(k,i) + 0.5*dt*H->fy(k,i);
	  //--- position update
	  X.qx(k-1,i) = X.qx(k,i) + dt*X.px(k-1,i);
	  X.qy(k-1,i) = X.qy(k,i) + dt*X.py(k-1,i);
	} 
      //--- Apply periodic BC on positions --- 
      Periodic_path(k-1);
      //--- Update the forces ---
      H->compute_force_path(X,k-1);
      //--- Final update of the momenta ---
      for(int i = 0 ; i < np; i++)
	{
	  //--- momenta update ---
	  X.px(k-1,i) += H->fx(k-1,i)*dt*0.5;
	  X.py(k-1,i) += H->fy(k-1,i)*dt*0.5;
	}
      //--- revert momenta again ---
      for (int i = 0; i < np; ++i)
	{
	  X.px(k-1,i) = -X.px(k-1,i);
	  X.py(k-1,i) = -X.py(k-1,i);
	}
    }
  //--- probability of the initial point of modified path ---
  H->compute_force_path(X,0);
  double final_energy = X.energy(0);
  for (int i = 0; i < np; i++)
    final_energy += 0.5*X.px(0,i)*X.px(0,i) + 0.5*X.py(0,i)*X.py(0,i);
  //--- Computation of the work in any case ---
  X.Work(0) = 0.;
  for (int k = 1; k < n_slices; k++)
    X.Work(k) = X.Work(k-1) + (X.Lambda(k)-X.Lambda(k-1))*X.insertion_energy(k-1);
  X.work = X.Work(n_slices-1);
  //--- weight correction ---
  double corr = 0.;
  for (int k = 1; k < ind+1; k++)
    {
      for (int i = 0; i < np; ++i)
	{
	  corr += pow(X.px(k,i)  ,2) - pow(X.inter_px(k,i)  ,2);
	  corr += pow(X.py(k,i)  ,2) - pow(X.inter_py(k,i)  ,2);
	  corr -= pow(old_px(k,i),2) - pow(old_inter_px(k,i),2);
	  corr -= pow(old_py(k,i),2) - pow(old_inter_py(k,i),2);
	}
    }
  //--- acceptance/rejection step ---
  double ratio = final_energy - initial_energy + 0.5*corr;
  //-- importance sampling in path space: sampling P(W) e^{-\beta\alpha W} --
  ratio += path_alpha*(X.work-old_work);
  ratio  = exp(-beta*ratio);
  if (ratio < g.random_number()) 
    {
      // rejection in this case
      rejection += 1;
      // go back to original path
      X.work = old_work;
      for (int k = 0; k < n_slices; k++)
	{
	  for (int i = 0; i < np; ++i)
	    {
	      X.px(k,i) = old_px(k,i); 
	      X.py(k,i) = old_py(k,i); 
	      X.inter_px(k,i) = old_inter_px(k,i); 
	      X.inter_py(k,i) = old_inter_py(k,i); 
	      X.qx(k,i) = old_qx(k,i);
	      X.qy(k,i) = old_qy(k,i);
	    }
	}
    }
  //-------------- End of path modification -------------
}


//----------------------------------------------------------
//
//     Sampling procedure = compute the trajectory
//
//----------------------------------------------------------

void algorithm::load()
{
  //--------------- Useful fields ---------------------
  ofstream WORK     ("../output/work");      // current value of the work
  ofstream ESTIMATE ("../output/DeltaF");    // Estimate of the free energy difference
  double SumWork_num, SumWork_denom;
  
  //------------- Initialization ----------------------
  Initialize();
  int acquisition = -1;
  H->compute_force_path(X,0);
  //--- Choose switching schedule ---
  for (int i = 0; i < n_slices; i++)
    X.Lambda(i) = schedule((i+1)*1./n_slices);
  //---- Thermalization of initial condition ----
  H->compute_force_path(X,0);
  for (int i = 0; i < n_iter_thm; i++)
    Langevin();
  //--- construction of initial path ----
  Initial_path();
  
  //-------------- Loop over iterations ---------------------
  SumWork_num   = 0.;
  SumWork_denom = 0.;
  cout << "------- Computation started -------" << endl;
  cout << endl;
  for(int Niter = 0; Niter < n_iter+1; Niter++)
    {
      //---- Monte Carlo path move ----
      //Hamiltonian_path();
      Langevin_path();
      
      //--- Update the estimator + debiasing ---
      SumWork_num   += exp(-beta*(1-path_alpha)*X.work); 
      SumWork_denom += exp( beta*path_alpha    *X.work); 

      //--- Outputs ---
      acquisition += 1;
      if (acquisition == freq)
	{
	  acquisition = 0;
	  cout     << "     Output at step " << Niter 
		   << "; rejection rate "    << rejection*1./(Niter+1) << endl;
	  WORK     << X.work     << endl;
	  ESTIMATE << Niter << "  " << -1./beta*log(SumWork_num/SumWork_denom) << endl;
	}
      
    }

  //------------- End of computation ---------------
  cout << endl;
  cout << "------- End of computation ------" << endl;
  cout << endl;
  cout << endl;
}









