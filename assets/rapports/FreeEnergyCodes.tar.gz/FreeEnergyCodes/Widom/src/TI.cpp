#include "algorithm.hpp"

//-----------------------------
//      Initialization
//----------------------------

void algorithm::Initialize()
{
  //--- Initialize the fields ---
  X.qx.set_size(nb_replicas,np);
  X.qx.zeros();
  X.qy.set_size(nb_replicas,np);
  X.qy.zeros();
  X.px.set_size(nb_replicas,np);
  X.px.zeros();
  X.py.set_size(nb_replicas,np);
  X.py.zeros();
  X.RFx.set_size(nb_replicas,np);
  X.RFx.zeros();
  X.RFy.set_size(nb_replicas,np);
  X.RFy.zeros();
  X.energy.set_size(nb_replicas);
  X.energy.zeros();
  X.potential_energy.set_size(nb_replicas);
  X.potential_energy.zeros();
  X.insertion_energy.set_size(nb_replicas);
  X.insertion_energy.zeros();
  X.Lambda.set_size(nb_replicas);
  X.Lambda.zeros();

  //------ TI ------
  Lambda.set_size(N_lambda+1);
  Lambda.zeros();  
  MeanForce.set_size(N_lambda+1);
  MeanForce.zeros();
  Bias.set_size(N_lambda);
  Bias.zeros();
  
  //--------- Loop over the replicas ---------
  for (int k = 0; k < nb_replicas; k++)
    {
      //---- Random value of lambda -----
      X.Lambda(k) = g.random_number();
      //---- Initial positions: on a lattice ---
      for (int i = 0; i < Ndim; ++i)  
	{
	  for (int j = 0; j < Ndim; ++j)  
	    {
	      X.qx(k,1+i*Ndim+j) = (0.5 + i)*a;
	      X.qy(k,1+i*Ndim+j) = (0.5 + j)*a;
	    }
	}
      //--- Place additional particle in the corner ---
      X.qx(k,0) = 0.;
      X.qy(k,0) = 0.;
      //--- Momenta and random forces ---
      for (int i = 0; i < np; ++i)
	{
      	  X.px(k,i)  = sqrt(1./beta)*g.rand_number(0,1);
      	  X.py(k,i)  = sqrt(1./beta)*g.rand_number(0,1);
      	  X.RFx(k,i) = g.rand_number(0,1);
      	  X.RFy(k,i) = g.rand_number(0,1);
      	}
    }	 
  
  //------------------- Screen output --------------------------
  cout << endl;
  cout << "------------------------------------------" << endl;
  cout << "           WIDOM INSERTION : TI           " << endl;
  cout << "------------------------------------------" << endl;
  cout << endl;
  cout << "        Initialization performed          " << endl;
  cout << "                                          " << endl;
  cout << "-----  Parameters of the computation -----" << endl;
  cout << endl;
  cout << " Dynamics                       : LANGEVIN " << endl;
  cout << " Time step                 (dt) : " << dt            << endl;
  cout << " Number of iterations           : " << n_iter        << endl;
  cout << " Outputs   every...steps        : " << freq          << endl; 
  cout << " Friction coefficient      (xi) : " << xi            << endl; 
  cout << " Inverse temperature     (beta) : " << beta          << endl; 
  cout << " Total number of particles (np) : " << np            << endl; 
  cout << " Elementary cell size       (a) : " << a             << endl;
  cout << " Particle density               : " << 1./(a*a)      << endl;
  cout << " LJ equilibrium distance  (sig) : " << sig           << endl; 
  cout << " LJ energy epsilon        (eps) : " << eps           << endl; 
  cout << " Number of intermediate stages  : " << N_lambda      << endl;
  cout << endl;
  cout << "----------------------------------------- " << endl;

  cout << endl;
      
}

//---------------------------------------------------------
//   Integration of the dynamics and auxiliary functions
//---------------------------------------------------------

//
double algorithm::schedule(double x)
{
  double val = pow(x,4);
  return val;
}

//-------- Apply periodic boundary conditions ---------
void algorithm::Periodic()
{
  Matrix temp;

  //-- x direction ---
  temp = X.qx;
  for (int k = 0; k < nb_replicas; k++)
    for (int i = 0; i < np; i++)
      temp(k,i) -= boxlg*floor( temp(k,i)*1./boxlg );
  X.qx = temp;

  //--- y direction
  temp = X.qy;
  for (int k = 0; k < nb_replicas; k++)
    for (int i = 0; i < np; i++) 
      temp(k,i) = temp(k,i) - boxlg*floor( temp(k,i)*1./boxlg );
  X.qy = temp;

}

//------------ Langevin dynamics -----------------------
void algorithm::Langevin()
{
  double sigma = sqrt(2*xi/beta);
  
  //--- BBK like algorithm ---
  for (int k = 0; k < nb_replicas; k++)
    {
      //--- Random terms
      for (int i = 0; i < np; ++i)
	{
	  X.RFx(k,i) = g.rand_number(0,1);
	  X.RFy(k,i) = g.rand_number(0,1);
	} 
      //--- random part of the force ---
      for (int i = 0; i < np; ++i)
	{
	  H->fx(k,i) += - xi*X.px(k,i) + sqrt(1/dt)*sigma*X.RFx(k,i);
	  H->fy(k,i) += - xi*X.py(k,i) + sqrt(1/dt)*sigma*X.RFy(k,i);
	} 
      for (int i = 0; i < np; ++i)
	{
	  //--- momenta update ---
	  X.px(k,i) += 0.5*dt*H->fx(k,i);
	  X.py(k,i) += 0.5*dt*H->fy(k,i);
	  //--- position update
	  X.qx(k,i) += dt*X.px(k,i);
	  X.qy(k,i) += dt*X.py(k,i);
	} 
    }
  //--- Apply periodic BC on positions --- 
  Periodic();
  //--- Update the forces ---
  H->compute_force(X);
  //--- Final update of the momenta ---
  for (int k = 0; k < nb_replicas; k++)
    {
      for(int i = 0 ; i < np; i++)
	{
	  X.px(k,i) = 1/( 1 + xi*dt*0.5 )
	    *( X.px(k,i) + H->fx(k,i)*dt*0.5 + 0.5*sqrt(dt)*sigma*X.RFx(k,i) );
	  X.py(k,i) = 1/( 1 + xi*dt*0.5 )
	    *( X.py(k,i) + H->fy(k,i)*dt*0.5 + 0.5*sqrt(dt)*sigma*X.RFy(k,i) );
	} 
    }
  //--- Add kinetic energy to the total energy ---
  H->add_k_energy(X);
  
  //--- End of Langevin ---
}



//----------------------------------------------------------
//
//     Sampling procedure = compute the trajectory
//
//----------------------------------------------------------

void algorithm::load()
{
  
  //--------------- Useful fields ---------------------
  ofstream ENERGY     ("../output/energy");        // energy as a function of time
  ofstream CURRENT_MF ("../output/current_mean_force"); // current estimate of mean force
  ofstream MEAN_FORCE ("../output/mean_force");         // mean force as a function of time
  ofstream BIAS       ("../output/PMF");                // associated PMF as a function of time
  double time;
  
  //------------- Initialization ----------------------
  Initialize();
  H->compute_force(X);
  int acquisition = -1;
   //--- Choose switching schedule ---
  for (int i = 0; i < 1+N_lambda; i++)
    Lambda(i) = schedule(i*1./N_lambda); 
  cout << "------- Computation started -------" << endl;
  cout << endl;
  
  //-------- Loop over the values of the reaction coordinate ---------
  for(int i = 0; i < N_lambda+1; i++)
    {
      //--- update value of the RC ---
      for (int k = 0; k < nb_replicas; k++)
	X.Lambda(k) = Lambda(i);
      SumMeanForces = 0.;
      cout << "   Sampling at lambda = " << Lambda(i) << endl;
      
      //--------------- Preliminary thermalization --------
      cout << "           --- thermalization " << endl;
      for(int Niter = 0; Niter < n_iter_thm; Niter++)
	Langevin();
      
      //-------------- Loop over time ---------------------
      cout << "           --- production " << endl;
      for(int Niter = 0; Niter < n_iter+1; Niter++)
	{
	  //---- Chosen dynamics ----
	  Langevin();
	  for (int k = 0; k < nb_replicas; k++)
	    SumMeanForces += X.insertion_energy(k);

	  //--- Outputs ---
	  acquisition += 1;
	  if (acquisition == freq)
	    {
	      acquisition = 0;
	      time = Niter*dt;
	      ENERGY << time << " " << X.energy(0) << " " 
		     << X.potential_energy(0) << " " 
		     << X.insertion_energy(0) << endl;
	      CURRENT_MF << time << " " 
			 << SumMeanForces/(nb_replicas*(Niter+1)) << endl;
	    }
	  
	}
      
      //--- keep track of the estimated mean force ---
      MeanForce(i) = SumMeanForces/(nb_replicas*(n_iter+1));
      MEAN_FORCE << Lambda(i) << " " << MeanForce(i) << endl;
    }

  //--- Compute finally approximation of PMF (simple quadrature) ---
  for (int k = 1; k < N_lambda+1; k++)
    {
      Bias(k) = Bias(k-1) + 0.5*(MeanForce(k)+MeanForce(k-1))*(Lambda(k)-Lambda(k-1));  
      BIAS << Lambda(k) << "  " << Bias(k) << endl;
    }

  //------------- End of computation ---------------
  cout << endl;
  cout << "------- End of computation ------" << endl;
  cout << endl;
  cout << endl;
}









