#include"hamiltonian.hpp"

//--- Compute kinetic energy ---
void hamiltonian::add_k_energy(particle & X)
{
  for (int k = 0; k < nb_sys; k++)
    for (int i = 0; i < np; i++)
      X.energy(k) += 0.5*X.px(k,i)*X.px(k,i) + 0.5*X.py(k,i)*X.py(k,i);
}


///-----------------------------------------------
//          Elementary interactions
//----------------------------------------------


//------ Compute length of the vector, up to periodic BC --------
void hamiltonian::lengthBC(double x1, double y1, double x2, double y2)
{
  dx = x1 - x2;
  dx -= boxlg*rint(dx*1./boxlg);
  dy = y1 - y2;
  dy -= boxlg*rint(dy*1./boxlg);
  dist = sqrt(dx*dx + dy*dy);    // distance up to BC 
  dx = dx/dist;                  // unit vector (dx,dy)
  dy = dy/dist;
}

//------ Regularized Lennard-Jones potential energy --------
double hamiltonian::potential(double d)  
{
  double pot;
  if (d < 0.8*sig)
    pot = A + B*pow(d,2);
  else 
    pot = 2.*eps*( 0.5*pow(sig/d,12)-pow(sig/d,6) ) - D  + C*(d - dcut);
  return pot; 
}

//------ Regularized Lennard-Jones force --------
double hamiltonian::force(double d)  
{
  double ff;
  if (d < 0.8*sig)
    ff = 2*B*d;
  else 
    ff = -12.*eps*( pow(sig/d,12)-pow(sig/d,6) )/d + C;
  return ff;
}


//----------------------------------------------------
//    Global force and potential energy computation
//----------------------------------------------------

void hamiltonian::compute_force(particle& X)
{
  
  //--- reset forces to 0 ---
  fx.zeros();
  fy.zeros();

  //---------- Loop over the replicas --------------
  for (int k = 0; k < nb_sys; k++)
    {
      //--- double loop over the particles, depending on their types ---
      double enpot           = 0.;
      double enpot_insertion = 0.;

      // 1 - interactions between the fluid particles
      for (int i = 1; i < np; ++i)
	{
	  for (int j = i+1; j < np; ++j)
	    { 
	      lengthBC(X.qx(k,j),X.qy(k,j),X.qx(k,i),X.qy(k,i));
	      if (dist < dcut)
		{
		  enpot += potential(dist);
		  act = force(dist);
		  fx(k,i) += act*dx;  
		  fy(k,i) += act*dy;
		  fx(k,j) -= act*dx;
		  fy(k,j) -= act*dy;
		}
	    }
	}
      
      // 2 - interactions with the inserted particle
      for (int i = 1; i < np; ++i)
	{ 
	  lengthBC(X.qx(k,i),X.qy(k,i),X.qx(k,0),X.qy(k,0));
	  if (dist < dcut)
	    {
	      enpot_insertion += potential(dist);
	      act = X.Lambda(k)*force(dist);
	      fx(k,0) += act*dx;  
	      fy(k,0) += act*dy;
	      fx(k,i) -= act*dx;
	      fy(k,i) -= act*dy;
	    }
	}
	
      // potential energy of replica 'k'
      X.insertion_energy(k) = enpot_insertion;
      X.energy(k)           = enpot + X.Lambda(k)*enpot_insertion;
      X.potential_energy(k) = enpot + X.Lambda(k)*enpot_insertion;
      
    }
  
  //--------- end of force computations ----
  
}

//------- Path sampling ; only forces for a given slice ------
void hamiltonian::compute_force_path(particle& X, int k)
{
  double enpot           = 0.;
  double enpot_insertion = 0.;
  //--- reset forces to 0 ---
  for (int i = 0; i < np; ++i)
    {
      fx(k,i) = 0;
      fy(k,i) = 0;
    }
  //--- double loop over the particles, depending on their types ---
  // 1 - interactions between the fluid particles
  for (int i = 1; i < np; ++i)
    {
      for (int j = i+1; j < np; ++j)
	{ 
	  lengthBC(X.qx(k,j),X.qy(k,j),X.qx(k,i),X.qy(k,i));
	  if (dist < dcut)
	    {
	      enpot += potential(dist);
	      act = force(dist);
	      fx(k,i) += act*dx;  
	      fy(k,i) += act*dy;
	      fx(k,j) -= act*dx;
	      fy(k,j) -= act*dy;
	    }
	}
    }
  // 2 - interactions with the inserted particle
  for (int i = 1; i < np; ++i)
    { 
      lengthBC(X.qx(k,i),X.qy(k,i),X.qx(k,0),X.qy(k,0));
      if (dist < dcut)
	{
	  enpot_insertion += potential(dist);
	  act = X.Lambda(k)*force(dist);
	  fx(k,0) += act*dx;  
	  fy(k,0) += act*dy;
	  fx(k,i) -= act*dx;
	  fy(k,i) -= act*dy;
	}
    }
  // potential energy of replica 'k'
  X.insertion_energy(k) = enpot_insertion;
  X.energy(k)           = enpot + X.Lambda(k)*enpot_insertion;
  X.potential_energy(k) = enpot + X.Lambda(k)*enpot_insertion;
  
}
  




