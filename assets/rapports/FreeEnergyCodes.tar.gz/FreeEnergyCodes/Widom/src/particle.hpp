#include "input.hpp"
#include "vector.hpp"
#include "matrix.hpp"

class particle
{
public:
  
  //---------------------------------
  //  All the masses are set to 1 !
  //---------------------------------
  
  //-------------------------------------------------
  //  General structure of the fields :  A(k,i)
  //  with k = index of the replica (0 -> nb_simu-1)
  //       i = particle number for a given replica
  //       (0 = inserted particle, 1 -> N-1 = solvent)
  //  For vectors : V(k) -> k = replica index
  //-------------------------------------------------

  Matrix qx, qy;        // positions 
  Matrix px, py;        // momenta
  Matrix RFx, RFy;      // noise term
  Vector Lambda;        // interaction strength

  Vector energy;           // total energy  
  Vector potential_energy; // potential energy 
  Vector insertion_energy; // insertion energy

  //--- For nonequilibrium switching -----
  Vector Work, Work_fwd, Work_bck;  // exerted works    
  Vector WorkUpdate;                // local work update (required for selection)
  Vector Birth, Death;              // birth and death times for selection process
  double nb_birth, nb_death;        // total number of deaths/births

  //--- For path sampling ---
  Matrix inter_px, inter_py; // intermediate momenta
  double work;

  //--- Creation/destruction ---
  particle(){};
  particle(const input& I);

};


