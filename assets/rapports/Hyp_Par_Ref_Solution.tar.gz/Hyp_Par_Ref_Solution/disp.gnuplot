###############################
# Tony LELIEVRE. 23 / 03 / 04 #
###############################
#
# To be used with gnuplot.
#
# Syntax:
# gnuplot
# call 'disp.gnuplot' number_of_test_case
#
# with number_of_test_case=1,2 or 3.
#
# See Reference solution, Figure 2, 3, 4.
#
###############################

# For the (renormalized) energy and the L^\infty norm
plot 'Case_$0.gnu' using 1:12 title 'energy' with lines, 'Case_$0.gnu' using 1:11 title 'L^\infty norm' with lines

pause -1  "Renormalized energy and L^\infty norm. Hit return to continue"

# For the flux at 1 and the jump at 2
plot 'Case_$0.gnu' using 1:6 title 'flux at 1' with lines, 'Case_$0.gnu' using 1:7 title 'jump at 2' with lines

pause -1  "Flux at 1 and jump at 2. Hit return to continue"

# For the mass
plot 'Case_$0.gnu' using 1:2 title 'mass on (0,1)' with lines, 'Case_$0.gnu'   using 1:3 title 'mass on (0,2)' with lines,  'Case_$0.gnu'  using 1:4 title 'total mass'  with lines

pause -1  "Mass. Hit return to continue"

# To display the profiles of concentration at different timesteps.

ymax=1.1

plot [][0:ymax] 'Case_$0_profile.gnu' using 1:2 title 't=0.' with lines, 'Case_$0_profile.gnu' using 1:3 title 't=0.5' with lines, 'Case_$0_profile.gnu' using 1:4 title 't=1.' with lines

pause -1  "Some profiles (1). Hit return to continue"

plot [][0:ymax] 'Case_$0_profile.gnu' using 1:5 title 't=1.5' with lines, 'Case_$0_profile.gnu' using 1:6 title 't=2.' with lines, 'Case_$0_profile.gnu' using 1:7 title 't=2.5' with lines

pause -1  "Some profiles (2). Hit return to continue"

plot [][0:ymax] 'Case_$0_profile.gnu' using 1:8 title 't=3.' with lines, 'Case_$0_profile.gnu' using 1:9 title 't=4.' with lines, 'Case_$0_profile.gnu' using 1:10 title 't=5.' with lines

pause -1  "Some profiles (3). Hit return to continue"
