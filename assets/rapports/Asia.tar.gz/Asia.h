/*****************************************************************************/
/********               Simulation of Asian options             **************/
/*                                                                           */
/************************ Tony Lelievre January 2004  ************************/
/*****************************************************************************/
#ifndef _ASIA_H_INCLUDE
#define _ASIA_H_INCLUDE

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <iostream.h>
#include <fstream.h>
#include <string>
#include <math.h>

#define PI 3.1415926535897932384626
#define EPSILON 1.e-10

// Nom Probleme
char nom_pb[20];
char pref_nom_fichier[50];

// Parametres financiers
double T,sigma,r,S0,K;

// Parametres numeriques
int J,N;
double xmax;
double dt,dx;


// Matrices
double* Mn_inf, * Mn_diag, * Mn_up;
double* Mn_plus_1_inf, * Mn_plus_1_diag, * Mn_plus_1_up;
double* L_diag, * L_inf, * U_up;

// Vecteur
double* Fold, * Fnew;
double* scd_membre;

// Pour le post-traitement
char file_mtv[100];
char titre[40];
char tps[10];


#endif
