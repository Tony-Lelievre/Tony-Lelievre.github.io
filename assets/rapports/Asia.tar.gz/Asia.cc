/*****************************************************************************/
/********               Simulation of Asian options             **************/
/*                                                                           */
/************************ Tony Lelievre January 2004  ************************/
/*****************************************************************************/

double tol=1.e-10;

#include "Asia.h"

void  Titre_JN(int J,int N,char *titre){
  char str[10];
  strcpy(titre,"'J=");
  sprintf(str,"%d",J);
  strcat(titre,str);
  strcat(titre," N=");
  sprintf(str,"%d",N);
  strcat(titre,str);

}

// Use plotmtv to see the curves

void post_mtv (double* vec,int dim,int flag,char *nom_fichier,char *titre,int EF,double x_min, double x_max,double y_min,double y_max,char * xlabel, char* ylabel){
  // flag = 0 --> new file
  // flag = 1 --> continuing file

  double dx;

  dx=(x_max-x_min)/(dim-1);
  
  ofstream f;

  if(flag)
    f.open(nom_fichier,ios::app);
  else
    f.open(nom_fichier);

  f << "$ DATA = CURVE2D" << endl;
  f << "% toplabel= "<<titre<<endl;
  f << "% xmin = "<<x_min<<endl;
  f << "% ymin = "<<y_min<<endl;
  f << "% ymax = "<<y_max<<endl;
  f << "% xlabel = "<<xlabel<<endl;
  f << "% ylabel = "<<ylabel<<endl;

  for(int i=0;i<dim;i++)
	f<<(x_min+i*dx)<<"  "<<vec[i]<<endl;

  f<<endl;

}

double max(double a, double b)
{
  if (a>b) return a;
  return b;
}


template  <class T> void Lit_item(istream& from,char *_titre, T *val){
  char titre[80];
  char c;

  from.get(titre,80,':');
  from.get(c);

  if(strcmp(titre,_titre)){
    cout << "Title is '" << titre <<"' though expecting '"
	 << _titre << "'." << endl;
    exit(1);
  }

  from>>*val;
  from.get(titre,80,'\n');
  from.get(c);
}

void Lit_item_string (istream& from,char *_titre, char *val){
  char titre[80];
  char c;

  from.get(titre,80,':');
  from.get(c);

  if(strcmp(titre,_titre)){
    cout << "Title is '" << titre <<"' though expecting '"
	 << _titre << "'." << endl;
    exit(1);
  }

  from.get(c); 
  from.get(val,80,'\n');
  from.get(c);
}

void Lit_Parametres (int argc, char *argv[]){
  char nom_fichier[200];

  if (argc!=2){
    cout<<"Asia [data file]"<<endl;
    exit(1);
  }
  
  strcpy(nom_fichier,argv[1]);
  ifstream from(nom_fichier);
  if(!from){
   cout << "Error : no data file :" << nom_fichier << endl;
   exit(1);
  }

  Lit_item_string(from,"Name of problem",nom_pb);
  Lit_item<double>(from,"Maturity",&T);
  Lit_item<double>(from,"Volatility",&sigma);
  Lit_item<double>(from,"Interest rate",&r);
  Lit_item<double>(from,"Initial value",&S0);
  Lit_item<double>(from,"Strike",&K);
  Lit_item<int>(from,"J",&J);
  Lit_item<int>(from,"N",&N);

  strcpy(pref_nom_fichier,"./");
  strcat(pref_nom_fichier,nom_pb);
  
}

void Affiche_Parametres (void){

  cout<<"Name of problem: "<<nom_pb<<endl;

  cout<<"Financial parameters"<<endl<<endl;
  cout<<"Maturity: "<<T<<endl;
  cout<<"Volatility: "<<sigma<<endl;
  cout<<"Interest rate: "<<r<<endl;
  cout<<"Initial value: "<<S0<<endl;
  cout<<"Strike: "<<K<<endl;
  cout<<endl;

  cout<<"Numerical parameters"<<endl<<endl;
  cout<<"J: "<<J<<endl;
  cout<<"N: "<<N<<endl;

  cout<<endl;  
}

//  LU inversion for tridiagonal matrix

void Initinv_Crout(double *A_inf, double *A_diag, double *A_up,int n_0 , int dim){
  
  L_diag[0]=A_diag[n_0+0];
  U_up[0]=A_up[n_0+0]/L_diag[0];

  for(int i=1;i<=dim-2;i++){
	L_inf[i-1]=A_inf[n_0+i];
	L_diag[i]=A_diag[n_0+i]-L_inf[i-1]*U_up[i-1];
	U_up[i]=A_up[n_0+i]/L_diag[i];
  }
  L_inf[dim-2]=A_inf[n_0+dim-1];
  L_diag[dim-1]=A_diag[n_0+dim-1]-L_inf[dim-2]*U_up[dim-2];

}

void inv_Crout(double *v,double *sol,double *A_inf, double *A_diag, double *A_up,int n_0 , int dim){
  
  Initinv_Crout(A_inf,A_diag,A_up,n_0,dim);
  
  sol[n_0]=v[n_0]/L_diag[0];
  for (int i=1;i<dim;i++)
    sol[n_0+i]=(v[n_0+i]-L_inf[i-1]*sol[n_0+i-1])/L_diag[i];
  
  for (int i=dim-2;i>=0;i--)
    sol[n_0+i]=(sol[n_0+i]-U_up[i]*sol[n_0+i+1]);

}

// Construction des matrices au temps t_n
void Construit_Matrices_CN(int n){

  double val1,val2,facmul;

  // Matrix initialisation
  
  //  ( - Id / dt + 0.5 * A(t_n} + 0.5 * B_{t_n} )
  //  ( - Id / dt - 0.5 * A(t_n} - 0.5 * B_{t_n} )

  // Mn
  for (int i=n+1;i<=N+J;i++){
	Mn_inf[i]=0.;
	Mn_diag[i]=0.;
	Mn_up[i]=0.;
  }

  // M(n+1)
  for (int i=n+1;i<=N+J;i++){
	Mn_plus_1_inf[i]=0.;
	Mn_plus_1_diag[i]=0.;
	Mn_plus_1_up[i]=0.;
  }

  // Mn
  facmul=0.5*(sigma*sigma/2);
  for (int i=n+1;i<N+J;i++){
	val1=facmul*(i-0.5-n)*(i-0.5-n);
	val2=facmul*(i+0.5-n)*(i+0.5-n);
	Mn_inf[i]+=val1;
	Mn_diag[i]+=-val2-val1;
	Mn_up[i]+=val2;
  }
  val1=facmul*(N+J-0.5-n)*(N+J-0.5-n);
  val2=facmul*(N+J+0.5-n)*(N+J+0.5-n);
  Mn_inf[N+J]+=val1;
  Mn_diag[N+J]+=-val1;

  // M(n+1)
  facmul=-0.5*(sigma*sigma/2);
  for (int i=n+1;i<N+J;i++){
	val1=facmul*(i-0.5-(n+1))*(i-0.5-(n+1));
	val2=facmul*(i+0.5-(n+1))*(i+0.5-(n+1));
	Mn_plus_1_inf[i]+=val1;
	Mn_plus_1_diag[i]+=-val2-val1;
	Mn_plus_1_up[i]+=val2;
  }
  val1=facmul*(N+J-0.5-(n+1))*(N+J-0.5-(n+1));
  val2=facmul*(N+J+0.5-(n+1))*(N+J+0.5-(n+1));
  Mn_plus_1_inf[N+J]+=val1;
  Mn_plus_1_diag[N+J]+=-val1;

  // Mn
  facmul=0.5*(-(r+sigma*sigma)/2);
  for (int i=n+1;i<N+J;i++)
	{
	  val1=facmul*(i-0.5-n);
	  val2=facmul*(i+0.5-n);
	  Mn_inf[i]+=-val1;
	  Mn_diag[i]+=-facmul;
	  Mn_up[i]+=val2;
	}
  val1=facmul*(N+J-0.5-n);
  val2=facmul*(N+J+0.5-n);
  Mn_inf[N+J]+=-val1;
  Mn_diag[N+J]+=val1;

  // M(n+1)
  facmul=-0.5*(-(r+sigma*sigma)/2);
  for (int i=n+1;i<N+J;i++)
	{
	  val1=facmul*(i-0.5-(n+1));
	  val2=facmul*(i+0.5-(n+1));
	  Mn_plus_1_inf[i]+=-val1;
	  Mn_plus_1_diag[i]+=-facmul;
	  Mn_plus_1_up[i]+=val2;
	}
  val1=facmul*(N+J-0.5-(n+1));
  val2=facmul*(N+J+0.5-(n+1));
  Mn_plus_1_inf[N+J]+=-val1;
  Mn_plus_1_diag[N+J]+=val1;  
  
  // Mn et M(n+1)
  for (int i=n+1;i<N+J;i++)
	{
	  Mn_diag[i]+=-1./dt;
	  Mn_plus_1_diag[i]+=-1./dt;
	  
	}
  Mn_diag[N+J]+=-0.5/dt;
  Mn_plus_1_diag[N+J]+=-0.5/dt;
  
}


void Calcul_Prix(double*F,double & prix, double & delta )
{
  double x=K/S0;
  int i=(int)floor((K/S0)/dx);
  double a,b,c,d;
  double aprime,bprime,cprime,dprime;
  
  // Interpolation order 3

  a=(i*dx-x)*((i+1)*dx-x)*((i+2)*dx-x)/(dx*2*dx*3*dx);
  b=(x-(i-1)*dx)*((i+1)*dx-x)*((i+2)*dx-x)/(dx*dx*2*dx);
  c=(x-(i-1)*dx)*(x-i*dx)*((i+2)*dx-x)/(2*dx*dx*dx);
  d=(x-(i-1)*dx)*(x-i*dx)*(x-(i+1)*dx)/(3*dx*2*dx*dx);
  
  aprime=((-1.)*((i+1)*dx-x)*((i+2)*dx-x)+(i*dx-x)*(-1.)*((i+2)*dx-x)+(i*dx-x)*((i+1)*dx-x)*(-1.))/(dx*2*dx*3*dx);
  bprime=((1.)*((i+1)*dx-x)*((i+2)*dx-x)+(x-(i-1)*dx)*(-1.)*((i+2)*dx-x)+(x-(i-1)*dx)*((i+1)*dx-x)*(-1.))/(dx*dx*2*dx);
  cprime=((1.)*(x-i*dx)*((i+2)*dx-x)+(x-(i-1)*dx)*(1.)*((i+2)*dx-x)+(x-(i-1)*dx)*(x-i*dx)*(-1.))/(2*dx*dx*dx);
  dprime=((1.)*(x-i*dx)*(x-(i+1)*dx)+(x-(i-1)*dx)*(1.)*(x-(i+1)*dx)+(x-(i-1)*dx)*(x-i*dx)*(1.))/(3*dx*2*dx*dx);
  
  prix=S0*(a*F[i-1]+b*F[i]+c*F[i+1]+d*F[i+2]);
  delta=(a*F[i-1]+b*F[i]+c*F[i+1]+d*F[i+2])-(K/S0)*(aprime*F[i-1]+bprime*F[i]+cprime*F[i+1]+dprime*F[i+2]);
  
}

int Calc(int flag,double & prix, double &delta ){
  // flag = 0 --> no plotmtv file
  // flag = 1 --> plotmtv file

  double t;

  double CL;
  int n_0,dim;
  
  
  // Final condition

  for (int i=0;i<=N+J;i++)
	Fold[i]=max(0,(1-i*dx));
  
  if (flag){
    strcpy(file_mtv,pref_nom_fichier);
    strcat(file_mtv,"_f.mtv");
    Titre_JN(J,N,titre);
    strcat(titre," t=T'");
	post_mtv(Fold,N+J+1,0,file_mtv,titre,1,0,xmax,0.,1.,"t","f");
  }

  
  // Time stepping

  for (int timestep=N-1;timestep>=0;timestep--){
    t=timestep*dt;
	
	n_0=timestep+1; // first unknown index
	dim=N+J-timestep; // dimension of the matrix
	
	// Matrix
	Construit_Matrices_CN(timestep);

	// RHS
	for (int i=n_0;i<N+J;i++)
	  scd_membre[i]=Fold[i-1]*Mn_plus_1_inf[i]+Fold[i]*Mn_plus_1_diag[i]+Fold[i+1]*Mn_plus_1_up[i];
	scd_membre[N+J]=Fold[N+J-1]*Mn_plus_1_inf[N+J]+Fold[N+J]*Mn_plus_1_diag[N+J];
	// Left boundary condition
	if (fabs(r)>EPSILON)
	  CL=(1/(r*T))*(1- exp(-r*(T-t)) );
	else
	  CL=(T-t)/T;
	scd_membre[n_0]-=CL*Mn_inf[n_0];

    // Inversion of matrix
	inv_Crout(scd_membre,Fnew,Mn_inf,Mn_diag,Mn_up,n_0,dim);

	// Explicit solution on the left
	if (fabs(r)>EPSILON)
	  for (int i=0;i<=timestep;i++)
		Fold[i]=(1/(r*T))*(1- exp(-r*(T-t)) ) - (i*dx-t/T)*exp(-r*(T-t));
	else
	  for (int i=0;i<=timestep;i++)
		Fold[i]=(T-t)/T - (i*dx-t/T);

	for (int i=n_0;i<=N+J;i++)
	  Fold[i]=Fnew[i];
		
    // Post-processing (100 divides N)
    if (flag && ((timestep % (N/100))==0)){
	  strcpy(file_mtv,pref_nom_fichier);
	  strcat(file_mtv,"_f.mtv");
	  Titre_JN(J,N,titre);
      strcpy(titre,"t=");
      sprintf(tps,"%g",t);
	  strcat(titre,tps);
	  post_mtv(Fold,N+J+1,1,file_mtv,titre,1,0,xmax,0.,1.,"t","f");
	}
  }


  // Price computation
  
  Calcul_Prix(Fold,prix,delta);
  
  return 1;

}

int main(int argc,char *argv[]){

  double prix,delta;

  Lit_Parametres (argc,argv);
  Affiche_Parametres();
  dt=T/N;
  dx=dt/T;
  xmax=(N+J)*dx;

  L_diag= new double[N+J+1];
  L_inf= new double[N+J+1];
  U_up= new double[N+J+1];
  Mn_inf= new double[N+J+1];
  Mn_diag= new double[N+J+1];
  Mn_up= new double[N+J+1];
  Mn_plus_1_inf= new double[N+J+1];
  Mn_plus_1_diag= new double[N+J+1];
  Mn_plus_1_up= new double[N+J+1];
  Fold= new double[N+J+1];
  Fnew= new double[N+J+1];
  scd_membre= new double[N+J+1];
  

  cout.precision(10);
  
  Calc(0,prix,delta);
  // Calc(1,prix,delta);

  cout<<"Prix: "<<prix<<endl;
  cout<<"Delta: "<<delta<<endl;

  cout<<endl;
  
  return 1;

}
